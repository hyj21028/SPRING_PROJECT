/**
 * 
 */


	function mainBack(){
		location.href="main.jsp"
	}
