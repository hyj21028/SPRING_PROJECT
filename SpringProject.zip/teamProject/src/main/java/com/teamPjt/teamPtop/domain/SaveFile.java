package com.teamPjt.teamPtop.domain;

import lombok.Data;

@Data
public class SaveFile {
	private int fno;
	private String filename;
	private int bno;

}
