package com.teamPjt.teamPtop.domain;

import lombok.Data;

@Data
public class fileVO {

	private int fno;
	private int bno;
	private String filename;
}
