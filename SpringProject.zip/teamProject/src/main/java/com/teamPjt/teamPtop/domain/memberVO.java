package com.teamPjt.teamPtop.domain;

import lombok.Data;

@Data
public class memberVO {
	private int mno;
	private String id;
	private String password;
	private String nickname;
	private String name;
	private String mail;
}
